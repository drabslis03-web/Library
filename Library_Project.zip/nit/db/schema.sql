-- NIT Library Management & Analytics — SQLite schema
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS departments (
  code TEXT PRIMARY KEY,            -- programme code, e.g. BCS
  course TEXT NOT NULL,             -- e.g. B.Tech - Computer Science and Engineering
  department TEXT NOT NULL          -- e.g. Computer Science and Engineering
);

CREATE TABLE IF NOT EXISTS members (
  member_id TEXT PRIMARY KEY,       -- roll no / staff id
  name TEXT NOT NULL,
  designation TEXT,
  grp TEXT NOT NULL CHECK (grp IN ('UG','PG','Faculty','Staff','Research Scholar')),
  dept_code TEXT REFERENCES departments(code) ON UPDATE CASCADE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS books (
  acc_no TEXT PRIMARY KEY,          -- accession number
  type TEXT CHECK (type IN ('P','G')),  -- Purchased / Gift
  bill_no TEXT, call_no TEXT,
  title TEXT NOT NULL, author TEXT, publisher TEXT,
  year INTEGER, price REAL, subject TEXT, supplier TEXT, isbn TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Gate / footfall register
CREATE TABLE IF NOT EXISTS visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  member_id TEXT NOT NULL REFERENCES members(member_id) ON UPDATE CASCADE ON DELETE CASCADE,
  visit_date TEXT NOT NULL,         -- YYYY-MM-DD
  in_min INTEGER NOT NULL,          -- minutes after midnight
  out_min INTEGER,                  -- NULL or = in_min when no check-out
  duration_min INTEGER NOT NULL DEFAULT 0
);

-- Circulation
CREATE TABLE IF NOT EXISTS issues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  acc_no TEXT NOT NULL,             -- soft link: old issues may reference withdrawn books
  member_id TEXT NOT NULL REFERENCES members(member_id) ON UPDATE CASCADE ON DELETE CASCADE,
  issue_date TEXT NOT NULL, due_date TEXT, return_date TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  action TEXT NOT NULL, tbl TEXT NOT NULL, detail TEXT
);

CREATE INDEX IF NOT EXISTS ix_members_grp   ON members(grp);
CREATE INDEX IF NOT EXISTS ix_members_dept  ON members(dept_code);
CREATE INDEX IF NOT EXISTS ix_books_subject ON books(subject);
CREATE INDEX IF NOT EXISTS ix_books_title   ON books(title);
CREATE INDEX IF NOT EXISTS ix_visits_date   ON visits(visit_date);
CREATE INDEX IF NOT EXISTS ix_visits_member ON visits(member_id);
CREATE INDEX IF NOT EXISTS ix_issues_date   ON issues(issue_date);
CREATE INDEX IF NOT EXISTS ix_issues_acc    ON issues(acc_no);
CREATE INDEX IF NOT EXISTS ix_issues_member ON issues(member_id);

INSERT OR IGNORE INTO settings(key,value) VALUES ('library_name','NIT Library');
