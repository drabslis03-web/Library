#!/usr/bin/env python3
"""NIT Library dashboard server — Python standard library only.   python server.py [port]"""
import sqlite3, json, os, sys, csv, io, mimetypes
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
ROOT=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(ROOT,'db','library.db'); STATIC=os.path.join(ROOT,'static')

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c
def rows(c,sql,a=()): return [dict(r) for r in c.execute(sql,a).fetchall()]
def one(c,sql,a=()): r=c.execute(sql,a).fetchone(); return r[0] if r else None
def mins(t):
    h,m=str(t).split(':')[:2]; return int(h)*60+int(m)

# search / list definitions: (select, search columns, order, from-clause)
LISTS={
 'members':("SELECT m.member_id,m.name,m.designation,m.grp,m.dept_code,d.department FROM members m LEFT JOIN departments d ON d.code=m.dept_code",
            ['m.member_id','m.name','d.department','m.grp'],"m.member_id"),
 'books':("SELECT acc_no,type,call_no,title,author,publisher,year,price,subject,isbn FROM books",
          ['acc_no','title','author','publisher','subject','isbn'],"CAST(acc_no AS INTEGER)"),
 'visits':("SELECT v.id,v.visit_date,v.member_id,m.name,m.grp,v.in_min,v.out_min,v.duration_min FROM visits v LEFT JOIN members m ON m.member_id=v.member_id",
           ['v.member_id','m.name','v.visit_date'],"v.visit_date DESC,v.in_min DESC"),
 'issues':("SELECT i.id,i.issue_date,i.due_date,i.return_date,i.acc_no,b.title,i.member_id,m.name FROM issues i LEFT JOIN books b ON b.acc_no=i.acc_no LEFT JOIN members m ON m.member_id=i.member_id",
           ['i.acc_no','b.title','i.member_id','m.name','i.issue_date'],"i.issue_date DESC,i.id DESC")}
PK={'members':'member_id','books':'acc_no','visits':'id','issues':'id'}
PKQ={'members':'member_id','books':'acc_no','visits':'id','issues':'id'}

def charts(c,name,f,t,grp):
    vw,iw="visit_date BETWEEN ? AND ?","issue_date BETWEEN ? AND ?"; a=(f,t)
    if name=='daily':    return rows(c,f"SELECT visit_date x,COUNT(*) y FROM visits WHERE {vw} GROUP BY 1 ORDER BY 1",a)
    if name=='monthly':  return rows(c,f"SELECT substr(visit_date,1,7) x,COUNT(*) visits,COUNT(DISTINCT member_id) members FROM visits WHERE {vw} GROUP BY 1 ORDER BY 1",a)
    if name=='issues_monthly': return rows(c,f"SELECT substr(issue_date,1,7) x,COUNT(*) y FROM issues WHERE {iw} GROUP BY 1 ORDER BY 1",a)
    if name=='hourly':   return rows(c,f"SELECT in_min/60 x,COUNT(*) y FROM visits WHERE {vw} GROUP BY 1 ORDER BY 1",a)
    if name=='weekday':  return rows(c,f"SELECT CAST(strftime('%w',visit_date) AS INT) x,COUNT(*) y FROM visits WHERE {vw} GROUP BY 1 ORDER BY 1",a)
    if name=='group':    return rows(c,f"SELECT m.grp x,COUNT(*) y FROM visits v JOIN members m USING(member_id) WHERE v.{vw} GROUP BY 1 ORDER BY 2 DESC",a)
    if name=='dept':     return rows(c,f"SELECT COALESCE(d.department,'Unassigned') x,COUNT(*) y FROM visits v JOIN members m USING(member_id) LEFT JOIN departments d ON d.code=m.dept_code WHERE v.{vw} GROUP BY 1 ORDER BY 2 DESC",a)
    if name=='subjects': return rows(c,f"SELECT b.subject x,COUNT(*) y FROM issues i JOIN books b ON b.acc_no=i.acc_no WHERE i.{iw} GROUP BY 1 ORDER BY 2 DESC",a)
    if name=='topbooks': return rows(c,f"SELECT b.title x,b.author,COUNT(*) y FROM issues i JOIN books b ON b.acc_no=i.acc_no WHERE i.{iw} GROUP BY b.title,b.author ORDER BY 3 DESC LIMIT 10",a)
    if name=='topmembers': return rows(c,f"SELECT m.name x,m.member_id,m.grp,COUNT(*) y FROM visits v JOIN members m USING(member_id) WHERE v.{vw} GROUP BY m.member_id ORDER BY 4 DESC LIMIT 10",a)
    if name=='topreaders': return rows(c,f"SELECT m.name x,m.member_id,m.grp,COUNT(*) y FROM issues i JOIN members m USING(member_id) WHERE i.{iw} GROUP BY m.member_id ORDER BY 4 DESC LIMIT 10",a)
    return None

def summary(c,f,t):
    a=(f,t)
    return {'visits':one(c,"SELECT COUNT(*) FROM visits WHERE visit_date BETWEEN ? AND ?",a),
     'unique_visitors':one(c,"SELECT COUNT(DISTINCT member_id) FROM visits WHERE visit_date BETWEEN ? AND ?",a),
     'open_days':one(c,"SELECT COUNT(DISTINCT visit_date) FROM visits WHERE visit_date BETWEEN ? AND ?",a),
     'avg_stay_min':one(c,"SELECT ROUND(AVG(duration_min),1) FROM visits WHERE visit_date BETWEEN ? AND ? AND duration_min>0",a),
     'issues':one(c,"SELECT COUNT(*) FROM issues WHERE issue_date BETWEEN ? AND ?",a),
     'members':one(c,"SELECT COUNT(*) FROM members WHERE active=1"),'titles':one(c,"SELECT COUNT(DISTINCT title) FROM books"),
     'books':one(c,"SELECT COUNT(*) FROM books"),'collection_value':one(c,"SELECT ROUND(COALESCE(SUM(price),0)) FROM books")}

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def send(self,code,body,ctype='application/json'):
        b=body if isinstance(body,bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header('Content-Type',ctype+('; charset=utf-8' if ctype.startswith('text') or 'json' in ctype else ''))
        self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def body(self):
        n=int(self.headers.get('Content-Length') or 0); return json.loads(self.rfile.read(n) or b'{}')

    def do_GET(self):
        u=urlparse(self.path); p=unquote(u.path); q={k:v[0] for k,v in parse_qs(u.query).items()}
        if not p.startswith('/api/'):
            fp=os.path.normpath(os.path.join(STATIC,'index.html' if p=='/' else p.lstrip('/')))
            if not fp.startswith(STATIC) or not os.path.isfile(fp): return self.send(404,{'error':'not found'})
            return self.send(200,open(fp,'rb').read(),mimetypes.guess_type(fp)[0] or 'application/octet-stream')
        parts=p[5:].split('/'); c=db()
        try:
            lo=one(c,"SELECT MIN(visit_date) FROM visits") or '2000-01-01'; hi=one(c,"SELECT MAX(visit_date) FROM visits") or '2100-01-01'
            f,t=q.get('from') or lo,q.get('to') or hi
            if parts[0]=='meta': return self.send(200,{'library':one(c,"SELECT value FROM settings WHERE key='library_name'"),'from':lo,'to':hi,
                  'departments':rows(c,"SELECT * FROM departments ORDER BY code")})
            if parts[0]=='summary': return self.send(200,summary(c,f,t))
            if parts[0]=='chart':
                r=charts(c,parts[1],f,t,q.get('grp')); return self.send(200 if r is not None else 404,r if r is not None else {'error':'unknown chart'})
            if parts[0]=='export' and parts[1].endswith('.csv'):
                tb=parts[1][:-4]
                if tb not in LISTS: return self.send(404,{'error':'unknown table'})
                cur=c.execute(f"SELECT * FROM {tb}"); out=io.StringIO(); w=csv.writer(out); w.writerow([d[0] for d in cur.description]); w.writerows(cur.fetchall())
                return self.send(200,out.getvalue().encode(),'text/csv')
            if parts[0] in LISTS:
                sel,cols,order=LISTS[parts[0]]; page=max(0,int(q.get('page',0))); size=min(200,int(q.get('size',25))); wh,a=[],[]
                if q.get('q'): wh.append('('+' OR '.join(f"{x} LIKE ?" for x in cols)+')'); a+=[f"%{q['q']}%"]*len(cols)
                if parts[0]=='visits': wh.append("v.visit_date BETWEEN ? AND ?"); a+=[f,t]
                if parts[0]=='issues': wh.append("i.issue_date BETWEEN ? AND ?"); a+=[f,t]
                if q.get('grp') and parts[0] in('members','visits'): wh.append(('m.grp=?')); a.append(q['grp'])
                W=(' WHERE '+' AND '.join(wh)) if wh else ''
                total=one(c,f"SELECT COUNT(*) FROM ({sel}{W})",a)
                return self.send(200,{'total':total,'rows':rows(c,f"{sel}{W} ORDER BY {order} LIMIT ? OFFSET ?",a+[size,page*size])})
            self.send(404,{'error':'not found'})
        except Exception as e: self.send(400,{'error':str(e)})
        finally: c.close()

    def do_POST(self):
        parts=urlparse(self.path).path[5:].split('/'); tb=parts[0]; c=db()
        try:
            d=self.body()
            if tb=='visits':
                i=mins(d['in_time']); o=mins(d['out_time']) if d.get('out_time') else i
                c.execute("INSERT INTO visits(member_id,visit_date,in_min,out_min,duration_min) VALUES (?,?,?,?,?)",(d['member_id'].strip(),d['visit_date'],i,o,max(0,o-i)))
            elif tb=='issues':
                c.execute("INSERT INTO issues(acc_no,member_id,issue_date,due_date) VALUES (?,?,?,?)",(d['acc_no'].strip(),d['member_id'].strip(),d['issue_date'],d.get('due_date') or None))
            elif tb=='members':
                c.execute("INSERT INTO members(member_id,name,designation,grp,dept_code) VALUES (?,?,?,?,?)",(d['member_id'].strip(),d['name'].strip(),d.get('designation'),d['grp'],d.get('dept_code') or None))
            elif tb=='books':
                c.execute("INSERT INTO books(acc_no,type,call_no,title,author,publisher,year,price,subject,isbn) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (d['acc_no'].strip(),d.get('type') or 'P',d.get('call_no'),d['title'].strip(),d.get('author'),d.get('publisher'),d.get('year') or None,d.get('price') or None,d.get('subject'),d.get('isbn')))
            else: return self.send(404,{'error':'unknown table'})
            c.execute("INSERT INTO audit_log(action,tbl,detail) VALUES ('add',?,?)",(tb,json.dumps(d)[:500])); c.commit(); self.send(201,{'ok':True})
        except sqlite3.IntegrityError as e: self.send(409,{'error':'Rejected: '+str(e)})
        except Exception as e: self.send(400,{'error':'Bad request: '+str(e)})
        finally: c.close()

    def do_DELETE(self):
        parts=urlparse(self.path).path[5:].split('/'); c=db()
        try:
            tb,key=parts[0],unquote(parts[1])
            if tb not in PK: return self.send(404,{'error':'unknown table'})
            n=c.execute(f"DELETE FROM {tb} WHERE {PK[tb]}=?",(key,)).rowcount
            c.execute("INSERT INTO audit_log(action,tbl,detail) VALUES ('delete',?,?)",(tb,key)); c.commit(); self.send(200,{'deleted':n})
        except Exception as e: self.send(400,{'error':str(e)})
        finally: c.close()

if __name__=='__main__':
    if not os.path.exists(DB): sys.exit('Database not found. Run:  python seed.py')
    port=int(sys.argv[1]) if len(sys.argv)>1 else 8000
    print(f'NIT Library dashboard running at http://localhost:{port}  (Ctrl+C to stop)')
    ThreadingHTTPServer(('0.0.0.0',port),H).serve_forever()
