#!/usr/bin/env python3
"""Create db/library.db from schema.sql and (optionally) load the sample data.
   python seed.py            -> schema + sample data
   python seed.py --empty    -> schema only (then use import_csv.py for real data)"""
import sqlite3, json, sys, os, datetime as dt
ROOT=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(ROOT,'db','library.db')
EPOCH=dt.date(2018,1,1)
iso=lambda d:(EPOCH+dt.timedelta(days=d)).isoformat()
if os.path.exists(DB): os.remove(DB)
c=sqlite3.connect(DB); c.executescript(open(os.path.join(ROOT,'db','schema.sql')).read())
if '--empty' not in sys.argv:
    R=json.load(open(os.path.join(ROOT,'data','sample_data.json')))
    c.executemany('INSERT INTO departments VALUES (?,?,?)',[(k,v[0],v[1]) for k,v in R['depts'].items()])
    c.executemany('INSERT INTO members(member_id,name,designation,grp,dept_code) VALUES (?,?,?,?,?)',[m[:5] for m in R['members']])
    c.executemany('INSERT INTO books(acc_no,type,bill_no,call_no,title,author,publisher,year,price,subject,supplier,isbn) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',R['books'])
    ids=[m[0] for m in R['members']]; F=R['foot']
    c.executemany('INSERT INTO visits(member_id,visit_date,in_min,out_min,duration_min) VALUES (?,?,?,?,?)',
        [(ids[F[i]],iso(F[i+1]),F[i+2],F[i+3],F[i+4]) for i in range(0,len(F),5)])
    c.executemany('INSERT INTO issues(acc_no,member_id,issue_date) VALUES (?,?,?)',[(a,ids[mi],iso(d)) for a,mi,d in R['issues']])
c.commit()
for t in ('departments','members','books','visits','issues'):
    print(f"{t:12}", c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0])
print('Created',DB)
