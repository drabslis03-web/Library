# NIT Library — Management & Analytics Dashboard

A web application with a real SQLite database. Needs only Python 3.8+ (standard library, nothing to install).

## Run it
```
python seed.py        # (optional) rebuilds db/library.db with sample data; a ready database is included
python server.py      # then open http://localhost:8000     (python server.py 9000 for another port)
```
On Windows use `py` instead of `python`, or double-click `start.bat`. To open it from other computers on your network, use `http://<this-computer-ip>:8000`.

## Use your real NIT data
```
python seed.py --empty                       # empty database, schema only
python import_csv.py departments departments.csv
python import_csv.py members     members.csv
python import_csv.py books       books.csv
python import_csv.py visits      visits.csv
python import_csv.py issues      issues.csv
```
Import in that order (members need departments; visits and issues need members). CSV headers:

| table | columns |
|---|---|
| departments | code, course, department |
| members | member_id, name, designation, grp, dept_code (grp = UG, PG, Faculty, Staff or Research Scholar) |
| books | acc_no, type (P/G), bill_no, call_no, title, author, publisher, year, price, subject, supplier, isbn |
| visits | member_id, visit_date (YYYY-MM-DD), in_time (HH:MM), out_time (HH:MM) |
| issues | acc_no, member_id, issue_date, due_date, return_date |

## Files
| file | purpose |
|---|---|
| `db/schema.sql` | Database definition: 7 tables, constraints, indexes |
| `db/library.db` | The SQLite database |
| `seed.py` | Builds the database; loads sample data unless `--empty` |
| `import_csv.py` | Loads your CSV files |
| `server.py` | REST API + serves the dashboard |
| `static/index.html` | Dashboard: charts, search, add/delete records, CSV export |
| `data/sample_data.json` | Made-up sample data (not real NIT records) |

## API (JSON)
`GET /api/meta` · `/api/summary` · `/api/chart/<monthly|daily|weekday|hourly|group|dept|subjects|topbooks|topmembers|topreaders|issues_monthly>` (optional `from`, `to`)
`GET /api/<members|books|visits|issues>?q=&page=&size=` · `POST /api/<table>` · `DELETE /api/<table>/<key>` · `GET /api/export/<table>.csv`

## Notes
- There is no login: anyone who can reach the server can add and delete records. Use a trusted network or VPN.
- Back up by copying `db/library.db`. Every add/delete is logged in `audit_log`.
- The schema ports to MySQL/PostgreSQL with minor type changes (AUTOINCREMENT becomes AUTO_INCREMENT or SERIAL).
