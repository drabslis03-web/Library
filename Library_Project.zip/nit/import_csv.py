#!/usr/bin/env python3
"""Load real NIT data from CSV files into db/library.db (run `python seed.py --empty` first).
   python import_csv.py members members.csv
   Tables / required header columns:
     departments : code,course,department
     members     : member_id,name,designation,grp,dept_code          (grp = UG|PG|Faculty|Staff|Research Scholar)
     books       : acc_no,type,bill_no,call_no,title,author,publisher,year,price,subject,supplier,isbn
     visits      : member_id,visit_date,in_time,out_time              (date YYYY-MM-DD, time HH:MM)
     issues      : acc_no,member_id,issue_date[,due_date,return_date]"""
import sqlite3, csv, sys, os
DB=os.path.join(os.path.dirname(os.path.abspath(__file__)),'db','library.db')
COLS={'departments':['code','course','department'],'members':['member_id','name','designation','grp','dept_code'],
 'books':['acc_no','type','bill_no','call_no','title','author','publisher','year','price','subject','supplier','isbn'],
 'issues':['acc_no','member_id','issue_date','due_date','return_date']}
def mins(t):
    t=(t or '').strip()
    if not t: return None
    h,m=t.split(':')[:2]; return int(h)*60+int(m)
if len(sys.argv)<3 or sys.argv[1] not in list(COLS)+['visits']: sys.exit(__doc__)
tbl,path=sys.argv[1],sys.argv[2]; c=sqlite3.connect(DB); c.execute('PRAGMA foreign_keys=ON')
rows=list(csv.DictReader(open(path,encoding='utf-8-sig'))); n=0
for r in rows:
    r={k.strip():(v.strip() if v else None) for k,v in r.items()}
    if tbl=='visits':
        i,o=mins(r['in_time']),mins(r.get('out_time'))
        c.execute('INSERT INTO visits(member_id,visit_date,in_min,out_min,duration_min) VALUES (?,?,?,?,?)',(r['member_id'],r['visit_date'],i,o,max(0,(o or i)-i)))
    else:
        cols=COLS[tbl]; c.execute(f"INSERT OR REPLACE INTO {tbl}({','.join(cols)}) VALUES ({','.join('?'*len(cols))})",[r.get(k) for k in cols])
    n+=1
c.commit(); print(f'Imported {n} rows into {tbl}')
